package tw.tcnr21.m0506;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;

public class M0506 extends AppCompatActivity {

    private TextView t002;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.m0506);
        setupViewComponent();
    }

    private void setupViewComponent() {
        t002=(TextView)findViewById(R.id.m0506_t002);
        t002.setMovementMethod(ScrollingMovementMethod.getInstance());

    }
}